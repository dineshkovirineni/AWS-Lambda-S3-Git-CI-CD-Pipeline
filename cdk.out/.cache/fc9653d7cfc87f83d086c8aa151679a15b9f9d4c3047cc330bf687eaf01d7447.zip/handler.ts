import * as AWS from 'aws-sdk';

export const handle = async () => {
  console.log("Succesful lambda creation");
};
