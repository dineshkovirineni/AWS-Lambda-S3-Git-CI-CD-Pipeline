import * as AWS from 'aws-sdk';

export const handler = async () => {
  console.log("Succesful lambda creation");
};
